//
//  NoviApp.swift
//  Novi
//
//  Created by Ashton Ma on 4/23/25.
//

import SwiftUI

@main
struct NoviApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
