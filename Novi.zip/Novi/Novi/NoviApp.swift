//
//  NoviApp.swift
//  Novi
//
//  Created by Ashton Ma on 3/29/25.
//

import SwiftUI

@main
struct NoviApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
