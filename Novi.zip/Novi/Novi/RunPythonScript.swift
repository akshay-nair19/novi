//
//  RunPythonScript.swift
//  Novi
//
//  Created by Ashton Ma on 4/23/25.
//

import Foundation
import PythonKit


func RunPythonScript() -> PythonObject {
    let sys = Python.import("sys")
    sys.path.append("/Users/ashtonma/Novi/Novi/Novi/")
    let file = Python.import("Python_Code")
    
    let response = file.color_dectector()
    print(response)
    return response
}
