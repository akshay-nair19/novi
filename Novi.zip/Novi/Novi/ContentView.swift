//
//  ContentView.swift
//  Novi
//
//  Created by Ashton Ma on 3/29/25.
//

import SwiftUI



struct ContentView: View {
    
    var body: some View {
        
        NavigationView {
            VStack {
                
                
                // NavigationLink to Next Page
                NavigationLink(destination: WardrobeView()) {
                    Text("Wardrobe")
                        .font(.title)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
            .navigationTitle("Home")
        }
    }
}




#Preview {
    ContentView()
}
