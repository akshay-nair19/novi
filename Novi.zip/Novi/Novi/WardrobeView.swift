//
//  WardrobeView.swift
//  Novi
//
//  Created by Ashton Ma on 3/30/25.
//

import SwiftUI

struct WardrobeView: View {
    @ObservedObject var wardrobe = Wardrobe()
    @State private var selectedShirt: Shirt?
    @State private var selectedPant: Pant?
    @State private var showAddClothingView = false
    @State private var showHistoryView = false
    @State private var history = History()
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    Section(header: Text("Shirts")) {
                        ForEach(wardrobe.items.compactMap { $0 as? Shirt }) { shirt in
                            Button(action: { selectedShirt = shirt }) {
                                Text("\(shirt.color) Shirt")
                                    .padding()
                                    .background(selectedShirt?.id == shirt.id ? Color.blue.opacity(0.5) : Color.clear)
                                    .cornerRadius(8)
                            }
                        }
                    }
                    
                    Section(header: Text("Pants")) {
                        ForEach(wardrobe.items.compactMap { $0 as? Pant }) { pant in
                            Button(action: { selectedPant = pant }) {
                                Text("\(pant.color) Pant")
                                    .padding()
                                    .background(selectedPant?.id == pant.id ? Color.green.opacity(0.5) : Color.clear)
                                    .cornerRadius(8)
                            }
                        }
                    }
                }
                
                Button("Wear Outfit") {
                    if let shirt = selectedShirt, let pant = selectedPant {
                        history.wearOutfit(shirt: shirt, pant: pant)
                        selectedShirt = nil
                        selectedPant = nil
                    }
                }
                .padding()
                .disabled(selectedShirt == nil || selectedPant == nil)
                
                Button("View History") {
                    showHistoryView = true
                }
                .padding()
            }
            .navigationTitle("Wardrobe")
            .navigationBarItems(trailing: Button("Add") {
                showAddClothingView = true
            })
            .sheet(isPresented: $showAddClothingView) {
                AddClothingView(wardrobe: wardrobe)
            }
            .sheet(isPresented: $showHistoryView) {
                HistoryView(history: history)
            }
        }
    }
}

struct AddClothingView: View {
    @ObservedObject var wardrobe: Wardrobe
    @Environment(\.presentationMode) var presentationMode
    @State private var selectedType = "Shirt"
    @State private var selectedColor = "Red"
    let clothingTypes = ["Shirt", "Pant"]
    let colors = ["Red", "Blue", "Green", "Black", "White"]
    
    var body: some View {
        NavigationView {
            VStack{
                Form {
                    Picker("Type", selection: $selectedType) {
                        ForEach(clothingTypes, id: \.self) { Text($0) }
                    }
                    
                    Picker("Color", selection: $selectedColor) {
                        ForEach(colors, id: \.self) { Text($0) }
                    }
                    
                    Button("Add Clothing") {
                        let newItem: Clothing = selectedType == "Shirt" ?
                            Shirt(color: selectedColor, picture: "", size: "M") :
                            Pant(color: selectedColor, picture: "", size: "M")
                        
                        wardrobe.addItem(newItem)
                        presentationMode.wrappedValue.dismiss()
                    }
                }
                // NavigationLink for Camera Button
                NavigationLink(destination: UploadView()) {
                    Text("Upload Image")
                        .font(.title)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                
            }
           
            .navigationTitle("Add Clothing")
        }
    }
}

struct HistoryView: View {
    var history: History
    
    var body: some View {
        NavigationView {
            List {
                ForEach(Array(history.getHistory().enumerated()), id: \ .offset) { index, outfit in
                    Text("Outfit \(index + 1): Shirt(\(outfit.0.color)) - Pant(\(outfit.1.color))")
                }
            }
            .navigationTitle("Outfit History")
        }
    }
}


